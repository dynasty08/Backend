# 🚀 Complete Serverless Full-Stack Application

## 🎯 What This Project Is

This is a **complete full-stack serverless application** that demonstrates modern cloud architecture. It includes a **React/Angular frontend**, **serverless backend**, **user authentication**, and **database connectivity** - all running in AWS without managing any servers!

Think of it as a **digital restaurant** where:
- **Frontend** = The dining room (where customers interact)
- **API Gateway** = The waiter (takes orders and delivers food)
- **Lambda Functions** = The kitchen staff (each has a specific job)
- **Databases** = The pantry and storage (where ingredients/data are kept)
- **VPC** = The secure building (private network for sensitive operations)

## 🏗️ Complete System Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           FRONTEND (Angular)                                │
│                     Hosted on AWS S3 + CloudFront                           │
│                    http://awsdynasty.s3-website...                          │
└─────────────────────────┬───────────────────────────────────────────────────┘
                          │ HTTPS Requests
                          ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        API GATEWAY                                          │
│              Entry Point: mrshckarmg.execute-api...                         │
│                    Routes all HTTP requests                                 │
└─┬─────┬─────┬─────┬─────┬─────┬─────────────────────────────────────────────┘
  │     │     │     │     │     │
  ▼     ▼     ▼     ▼     ▼     ▼
┌────┐┌────┐┌────┐┌────┐┌────┐┌────┐┌──────────────┐
│GET ││POST││POST││GET ││GET ││GET ││GET           │
│/   ││/   ││/   ││/   ││/   ││/   ││/database     │
│hello│reg │login│users│sess │test │(VPC)         │
└────┘└────┘└────┘└────┘└────┘└────┘└──────────────┘
  │     │     │     │     │     │
  ▼     ▼     ▼     ▼     ▼     ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         LAMBDA FUNCTIONS                                    │
│                      (Serverless Compute)                                   │
│ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────────┐ │
│ │hello.js │ │register │ │login    │ │get-users│ │active   │ │test-db  │ │get-postgres │ │
│ │         │ │-simple  │ │-simple  │ │-simple  │ │sessions │ │.js      │ │-data.js     │ │
│ │Health   │ │.js      │ │.js      │ │.js      │ │.js      │ │         │ │(In VPC)     │ │
│ │Check    │ │Create   │ │Auth     │ │List     │ │Track    │ │Mock     │ │Real DB      │ │
│ │         │ │User     │ │User     │ │Users    │ │Sessions │ │Data     │ │Connection   │ │
│ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────┘ └─────────────┘ │
└─────────────────────────────────────────────────────────────────────────────┘
          │                              │                         │
          ▼                              ▼                         ▼
┌─────────────────┐              ┌─────────────────┐    ┌─────────────────────┐
│    DynamoDB     │              │   AWS Secrets   │    │    PostgreSQL       │
│  (User Data)    │              │    Manager      │    │      RDS            │
│                 │              │  (DB Creds)     │    │  (Business Data)    │
│ • User Auth     │              │                 │    │                     │
│ • Fast Access   │              │ • Encrypted     │    │ • In Private VPC    │
│ • NoSQL         │              │ • Secure        │    │ • Relational DB     │
│ • Serverless    │              │ • Auto-Rotate   │    │ • PostgreSQL 17.4   │
└─────────────────┘              └─────────────────┘    └─────────────────────┘
                                                                   ▲
                                                                   │
                                                        ┌─────────────────────┐
                                                        │       VPC           │
                                                        │  (Private Network)  │
                                                        │                     │
                                                        │ • NAT Gateway       │
                                                        │ • Private Subnets   │
                                                        │ • Security Groups   │
                                                        │ • Internet Access   │
                                                        └─────────────────────┘
```

## 📊 System Components Overview

| Component | Technology | Purpose | Location |
|-----------|------------|---------|----------|
| **Frontend** | Angular | User Interface | S3 Static Website |
| **API Gateway** | AWS API Gateway | HTTP Router | AWS Managed |
| **Backend Logic** | Lambda Functions | Business Logic | AWS Serverless |
| **User Database** | DynamoDB | User Authentication | AWS NoSQL |
| **Business Database** | PostgreSQL RDS | Application Data | AWS VPC |
| **Security** | VPC + Security Groups | Network Security | AWS Network |
| **Secrets** | AWS Secrets Manager | Database Credentials | AWS Managed |

## 🔄 Complete Request Flow (Step by Step)

### 🔹 User Registration Flow
```
1. User fills form on website
   ↓
2. Angular sends POST to /register
   ↓
3. API Gateway receives request
   ↓
4. Routes to register-simple.js Lambda
   ↓
5. Lambda checks if user exists in DynamoDB
   ↓
6. If new: encrypts password with bcrypt
   ↓
7. Saves user to DynamoDB table
   ↓
8. Returns success message to frontend
   ↓
9. User sees "Registration successful!"
```

### 🔹 User Login Flow
```
1. User enters email/password
   ↓
2. Angular sends POST to /login
   ↓
3. API Gateway routes to login-simple.js
   ↓
4. Lambda finds user in DynamoDB by email
   ↓
5. Compares password using bcrypt
   ↓
6. If valid: creates JWT token
   ↓
7. Returns token + user info
   ↓
8. Frontend stores token and redirects to dashboard
```

### 🔹 Dashboard Data Flow
```
1. User visits dashboard
   ↓
2. Angular makes multiple API calls:
   - GET /users (for user list)
   - GET /active-sessions (for session count)
   - GET /database (for PostgreSQL info)
   ↓
3. API Gateway routes to respective Lambdas
   ↓
4. get-users-simple.js → queries DynamoDB for all users
5. get-active-sessions.js → counts active users (last 24h)
6. get-postgres-data.js → connects to RDS via VPC
   ↓
7. All functions return data to frontend
   ↓
8. Dashboard displays combined information with real metrics
```

### 🔹 Active Session Tracking Flow
```
1. User logs in successfully
   ↓
2. login-simple.js updates user record:
   - lastLoginAt = current timestamp
   - isActive = true
   ↓
3. Dashboard loads and calls GET /active-sessions
   ↓
4. get-active-sessions.js scans DynamoDB:
   - Finds users with lastLoginAt < 24 hours ago
   - Counts users where isActive = true
   ↓
5. Returns real active session count
   ↓
6. Dashboard displays actual active users
```

## 🧩 Detailed Component Breakdown

### 🔹 Frontend (Angular Application)

**Location:** `FrontEnd/angularfolder/`
**Hosted:** AWS S3 Static Website
**URL:** `http://awsdynasty.s3-website-ap-southeast-1.amazonaws.com`

#### Key Components:
| File | Purpose | What It Does |
|------|---------|--------------|
| `app.component.ts` | Main App | Root component, handles routing |
| `login.component.ts` | Login Page | User authentication form |
| `register.component.ts` | Registration | New user signup form |
| `dashboard.component.ts` | Dashboard | Shows users + database info |
| `api.service.ts` | API Client | Makes HTTP calls to backend |
| `user.service.ts` | User Management | Handles user-related operations |

#### How Frontend Connects to Backend:
```typescript
// In environment.ts
apiUrl: 'https://mrshckarmg.execute-api.ap-southeast-1.amazonaws.com/dev'

// In api.service.ts
register(userData) {
  return this.http.post(`${this.apiUrl}/register`, userData);
}
```

### 🔹 Backend Lambda Functions

**Location:** `BackEnd/lambda/`
**Runtime:** Node.js 18.x
**Deployment:** AWS Lambda (Serverless)

#### Function Details:

| Function | File | HTTP Method | Endpoint | Database | VPC |
|----------|------|-------------|----------|----------|-----|
| **Health Check** | `hello.js` | GET | `/hello` | None | No |
| **User Registration** | `register-simple.js` | POST | `/register` | DynamoDB | No |
| **User Login** | `login-simple.js` | POST | `/login` | DynamoDB | No |
| **List Users** | `get-users-simple.js` | GET | `/users` | DynamoDB | No |
| **Active Sessions** | `get-active-sessions.js` | GET | `/active-sessions` | DynamoDB | No |
| **Mock Database** | `test-database.js` | GET | `/test-database` | None | No |
| **Real Database** | `get-postgres-data.js` | GET | `/database` | PostgreSQL | Yes |

#### Code Examples:

**Registration Function (register-simple.js):**
```javascript
exports.handler = async (event) => {
  // 1. Parse request data
  const { email, password, name } = JSON.parse(event.body);
  
  // 2. Check if user exists
  const existingUser = await dynamoDB.query({
    TableName: TABLE_NAME,
    IndexName: 'EmailIndex',
    KeyConditionExpression: 'email = :email',
    ExpressionAttributeValues: { ':email': email.toLowerCase() }
  }).promise();
  
  // 3. Hash password and save user
  const hashedPassword = await bcrypt.hash(password, 10);
  const userId = uuidv4();
  
  await dynamoDB.put({
    TableName: TABLE_NAME,
    Item: { userId, email, password: hashedPassword, name }
  }).promise();
  
  return { statusCode: 201, body: JSON.stringify({ message: 'User registered' }) };
};
```

**Active Sessions Function (get-active-sessions.js):**
```javascript
exports.handler = async (event) => {
  // 1. Calculate time threshold (24 hours ago)
  const now = new Date();
  const twentyFourHoursAgo = new Date(now.getTime() - 24 * 60 * 60 * 1000);
  
  // 2. Scan for active users
  const result = await dynamoDB.scan({
    TableName: TABLE_NAME,
    FilterExpression: 'lastLoginAt > :timeThreshold AND isActive = :active',
    ExpressionAttributeValues: {
      ':timeThreshold': twentyFourHoursAgo.toISOString(),
      ':active': true
    }
  }).promise();
  
  // 3. Return active session count
  return {
    statusCode: 200,
    body: JSON.stringify({
      activeSessions: result.Items.length,
      activeUsers: result.Items
    })
  };
};
```

**PostgreSQL Function (get-postgres-data.js):**
```javascript
exports.handler = async (event) => {
  // 1. Get database credentials from Secrets Manager
  const credentials = await getDbCredentials();
  
  // 2. Connect to PostgreSQL through VPC
  const pool = new Pool({
    host: process.env.DB_HOST,
    user: credentials.username,
    password: credentials.password,
    database: process.env.DB_NAME
  });
  
  // 3. Query database information
  const dbInfo = await pool.query('SELECT version()');
  const tables = await pool.query('SELECT table_name FROM information_schema.tables');
  
  return { statusCode: 200, body: JSON.stringify({ database: dbInfo, tables }) };
};
```

### 🔹 Database Architecture

#### DynamoDB (User Authentication & Session Tracking)
```
Table: my-backend-clean-dev-users
Primary Key: userId (String)
Global Secondary Index: EmailIndex (email)

Sample Record:
{
  "userId": "123e4567-e89b-12d3-a456-426614174000",
  "email": "user@example.com",
  "password": "$2b$10$encrypted_password_hash",
  "name": "John Doe",
  "createdAt": "2025-01-28T10:30:00.000Z",
  "lastLoginAt": "2025-01-28T15:45:30.000Z",
  "isActive": true
}

Session Tracking Fields:
- lastLoginAt: Timestamp of user's last login
- isActive: Boolean indicating if user is currently active
```

#### PostgreSQL RDS (Business Data)
```
Database: serverlessdatabase
Version: PostgreSQL 17.4
Host: serverlessdatabase.cv646auk2i3w.ap-southeast-1.rds.amazonaws.com
Location: Private VPC subnets

Connection: Through VPC with NAT Gateway
Security: Accessed only by Lambda functions in VPC
```

### 🔹 VPC Network Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                           VPC                                   │
│                    10.0.0.0/16                                  │
│                                                                 │
│  ┌─────────────────┐                 ┌─────────────────────────┐ │
│  │  Public Subnet  │                 │    Private Subnets      │ │
│  │   10.0.1.0/24   │                 │  10.0.2.0/24 (AZ-a)     │ │
│  │                 │                 │  10.0.3.0/24 (AZ-b)     │ │
│  │  ┌─────────────┐│                 │                         │ │
│  │  │NAT Gateway  ││◄────────────────│  ┌─────────────────────┐│ │
│  │  │             ││                 │  │ Lambda Functions    ││ │
│  │  │Elastic IP   ││                 │  │ PostgreSQL RDS      ││ │
│  │  └─────────────┘│                 │  │ (Private Network)   ││ │
│  └─────────────────┘                 │  └─────────────────────┘│ │
│           │                          └─────────────────────────┘ │
└───────────┼──────────────────────────────────────────────────────┘
            │
    ┌───────▼────────┐
    │Internet Gateway│
    └────────────────┘
            │
        Internet
```

#### Network Flow:
1. **Lambda functions** run in **private subnets**
2. **Database access** stays within VPC (secure)
3. **Internet access** goes through **NAT Gateway** in public subnet
4. **API Gateway responses** route back through NAT Gateway

## 🔐 Security Implementation

### Authentication & Authorization
| Security Layer | Implementation | Purpose |
|----------------|----------------|---------|
| **Password Hashing** | bcrypt with salt rounds | Protect user passwords |
| **JWT Tokens** | JSON Web Tokens | Stateless authentication |
| **CORS Headers** | Cross-Origin Resource Sharing | Allow frontend access |
| **VPC Isolation** | Private network | Secure database access |
| **Security Groups** | Network ACLs | Control traffic flow |
| **Secrets Manager** | Encrypted credential storage | Protect database passwords |
| **IAM Roles** | Least privilege access | Function-specific permissions |

### Security Group Configuration:
```
Lambda Security Group (sg-0ed89bc24456149e1):
Inbound:  None (Lambda doesn't receive direct traffic)
Outbound: HTTPS (443) → 0.0.0.0/0 (API Gateway responses)
          HTTP (80) → 0.0.0.0/0 (Internet access)
          PostgreSQL (5432) → 0.0.0.0/0 (Database access)

RDS Security Group:
Inbound:  PostgreSQL (5432) ← Lambda Security Group
Outbound: All traffic (default)
```

## 📊 API Endpoints Reference

### Complete API Documentation

| Method | Endpoint | Request Body | Response | Purpose |
|--------|----------|--------------|----------|---------|
| **GET** | `/hello` | None | `{"message": "Hello from Lambda!"}` | Health check |
| **POST** | `/register` | `{"email", "password", "name"}` | `{"message": "User registered", "user": {...}}` | Create account |
| **POST** | `/login` | `{"email", "password"}` | `{"token": "jwt...", "user": {...}}` | Authenticate |
| **GET** | `/users` | None | `{"users": [...]}` | List all users |
| **GET** | `/active-sessions` | None | `{"activeSessions": 5, "activeUsers": [...]}` | Count active sessions |
| **GET** | `/database` | None | `{"database": {...}, "tables": [...]}` | PostgreSQL info |
| **GET** | `/test-database` | None | `{"mockData": {...}}` | Mock database info |

### Sample API Calls:

**Registration:**
```bash
curl -X POST https://mrshckarmg.execute-api.ap-southeast-1.amazonaws.com/dev/register \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"securepass","name":"John Doe"}'
```

**Login:**
```bash
curl -X POST https://mrshckarmg.execute-api.ap-southeast-1.amazonaws.com/dev/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"securepass"}'
```

**Active Sessions:**
```bash
curl https://mrshckarmg.execute-api.ap-southeast-1.amazonaws.com/dev/active-sessions
```

## 🚀 Deployment Architecture

### Infrastructure as Code (serverless.yml)
```yaml
service: my-backend-clean
provider:
  name: aws
  runtime: nodejs18.x
  region: ap-southeast-1

functions:
  register:
    handler: lambda/register-simple.handler
    events:
      - http:
          path: /register
          method: post
          cors: true

  getActiveSessions:
    handler: lambda/get-active-sessions.handler
    events:
      - http:
          path: /active-sessions
          method: get
          cors: true

  getPostgresData:
    handler: lambda/get-postgres-data.handler
    vpc:
      securityGroupIds: [sg-0ed89bc24456149e1]
      subnetIds: [subnet-0733c251f5d150a45, subnet-0e4fc9f338aa5ad71]

resources:
  Resources:
    UsersTable:
      Type: AWS::DynamoDB::Table
      Properties:
        TableName: ${self:service}-${self:provider.stage}-users
```

### Deployment Process:
```
1. Code Development → Local IDE
2. Serverless Deploy → AWS CloudFormation
3. Infrastructure Creation → Lambda, API Gateway, DynamoDB
4. Frontend Build → Angular compilation
5. Static Hosting → S3 bucket deployment
6. DNS/CDN → CloudFront distribution (optional)
```

## 🔄 Data Flow Examples

### User Registration Complete Flow:
```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   Browser   │───►│   Angular   │───►│ API Gateway │───►│   Lambda    │
│ (User Form) │    │ (Frontend)  │    │  (Router)   │    │(register.js)│
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
                                                                 │
                                                                 ▼
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│   Success   │◄───│  Dashboard  │◄───│  Response   │◄───│  DynamoDB   │
│   Message   │    │   Redirect  │    │   (JSON)    │    │ (User Save) │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
```

### Database Query Flow:
```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  Dashboard  │───►│GET /database│───►│   Lambda    │───►│AWS Secrets  │
│   (Load)    │    │   Request   │    │(VPC Enabled)│    │  Manager    │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
       ▲                                      │                   │
       │                                      ▼                   ▼
┌─────────────┐                        ┌─────────────┐    ┌─────────────┐
│DB Info      │◄───────────────────────│  Process    │◄───│ PostgreSQL  │
│Display      │                        │   Query     │    │    RDS      │
└─────────────┘                        └─────────────┘    └─────────────┘
```

### Active Sessions Tracking Flow:
```
┌─────────────┐    ┌───────────────────┐    ┌─────────────┐    ┌─────────────┐
│  Dashboard  │────►│GET /active-sessions│────►│   Lambda    │────►│  DynamoDB   │
│   (Load)    │    │     Request       │    │(Count Users)│    │(Scan Active)│
└─────────────┘    └───────────────────┘    └─────────────┘    └─────────────┘
       ▲                                      │                   │
       │                                      ▼                   ▼
┌─────────────┐                        ┌─────────────┐    ┌─────────────┐
│Active Count │◄───────────────────────│   Process   │◄───│Filter Users │
│Display      │                        │Session Data │    │(Last 24h)   │
└─────────────┘                        └─────────────┘    └─────────────┘
```

## 🎯 Key Benefits & Features

### Scalability
- **Auto-scaling:** Lambda functions scale automatically
- **No server management:** AWS handles all infrastructure
- **Pay-per-use:** Only charged when functions execute
- **Global reach:** Can deploy to multiple regions

### Security
- **Zero-trust network:** VPC isolates database access
- **Encrypted storage:** All data encrypted at rest
- **Secure transmission:** HTTPS/TLS for all communications
- **Access control:** IAM roles with minimal permissions

### Performance
- **Fast startup:** Lambda cold start optimized
- **CDN ready:** Frontend can use CloudFront
- **Database optimization:** DynamoDB for fast user queries
- **Real-time metrics:** Active session tracking with live updates
- **Connection pooling:** PostgreSQL connections managed efficiently

### Cost Efficiency
- **Serverless pricing:** No idle server costs
- **Resource optimization:** Functions use only needed resources
- **Managed services:** Reduced operational overhead
- **Automatic scaling:** No over-provisioning

## 🔧 Environment Configuration

### Development Environment Variables:
```javascript
// Frontend (environment.ts)
export const environment = {
  production: false,
  apiUrl: 'https://mrshckarmg.execute-api.ap-southeast-1.amazonaws.com/dev',
  apiTimeout: 15000
};

// Backend (serverless.yml)
environment:
  USERS_TABLE: my-backend-clean-dev-users
  DB_HOST: serverlessdatabase.cv646auk2i3w.ap-southeast-1.rds.amazonaws.com
  DB_NAME: serverlessdatabase
  SECRET_ARN: arn:aws:secretsmanager:ap-southeast-1:194416698840:secret:...
```

## 🚦 Getting Started Guide

### Prerequisites:
- AWS Account with appropriate permissions
- Node.js 18+ installed
- Angular CLI installed
- Serverless Framework installed

### Deployment Steps:
```bash
# 1. Deploy Backend
cd BackEnd
npm install
serverless deploy

# 2. Build Frontend
cd ../FrontEnd/angularfolder
npm install
ng build

# 3. Deploy Frontend
aws s3 sync "dist/angularfolder/browser" s3://awsdynasty

# 4. Test Application
# Visit: http://awsdynasty.s3-website-ap-southeast-1.amazonaws.com
```

### Testing Checklist:
- [ ] Health check: GET /hello returns success
- [ ] User registration: Can create new account
- [ ] User login: Can authenticate with credentials
- [ ] Active sessions: GET /active-sessions returns count
- [ ] Dashboard: Shows user list, active sessions, and database info
- [ ] Database connection: PostgreSQL data displays correctly
- [ ] Session tracking: Active sessions count updates after login

## 🔍 Troubleshooting Guide

### Common Issues:

| Issue | Symptom | Solution |
|-------|---------|----------|
| **CORS Error** | Frontend can't call API | Check CORS headers in Lambda |
| **VPC Timeout** | Database endpoint times out | Verify NAT Gateway and security groups |
| **Auth Failure** | Login returns 401 | Check password hashing and JWT secret |
| **DB Connection** | PostgreSQL connection fails | Verify VPC configuration and credentials |

### Monitoring & Logs:
```bash
# View Lambda logs
serverless logs -f register --tail

# Check API Gateway logs
aws logs describe-log-groups --log-group-name-prefix "API-Gateway"

# Monitor DynamoDB metrics
aws cloudwatch get-metric-statistics --namespace AWS/DynamoDB
```

## 📈 Future Enhancements

### Potential Improvements:
- **Email verification** for user registration
- **Password reset** functionality
- **User profile management** with photo upload
- **Real-time notifications** using WebSockets
- **Advanced database queries** with search and filtering
- **Caching layer** with Redis/ElastiCache
- **CI/CD pipeline** with GitHub Actions
- **Multi-environment** deployment (dev/staging/prod)

### Architecture Evolution:
- **Microservices** - Split functions into separate services
- **Event-driven** - Add SQS/SNS for async processing
- **GraphQL** - Replace REST API with GraphQL
- **Container deployment** - Use ECS/Fargate for complex workloads

---

## 🎊 Conclusion

This project demonstrates a **complete modern serverless architecture** that combines:
- **Frontend:** Angular SPA with responsive design
- **Backend:** AWS Lambda functions with API Gateway
- **Databases:** DynamoDB for users, PostgreSQL for business data
- **Session Tracking:** Real-time active user monitoring
- **Security:** VPC, encryption, and proper access controls
- **Scalability:** Auto-scaling serverless components

The architecture is **production-ready**, **cost-effective**, and **highly scalable**, making it perfect for modern web applications that need to handle varying loads while maintaining security and performance.

**Total Infrastructure:** Fully serverless, no servers to manage, automatic scaling, pay-per-use pricing model.

**Perfect for:** Startups, MVPs, enterprise applications, learning cloud architecture, and building scalable web applications.